package ddwu.moblie.finalproject.ma01_20180999;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class UpdatePerformanceActivity extends AppCompatActivity {

    TextView tvTitle;
    TextView tvVenue;
    TextView tvPeriod;
    EditText etMemo;

    Performance performance;
    PerformanceDBHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_performance);

        performance = (Performance) getIntent().getSerializableExtra("performance");
        helper = new PerformanceDBHelper(this);

        tvTitle = findViewById(R.id.tvUpdatePerformanceTitle);
        tvTitle.setText(performance.getTitle());

        tvVenue = findViewById(R.id.tvUpdatePerformanceVenue);
        tvVenue.setText(performance.getVenue());

        tvPeriod = findViewById(R.id.tvUpdatePerformancePeriod);
        tvPeriod.setText(performance.getPeriod());

        etMemo = findViewById(R.id.etUpdatePerformanceMemo);
        etMemo.setText(performance.getMemo());
    }

    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.btnViewMap:
                Intent intent = new Intent(UpdatePerformanceActivity.this, MapsActivity.class);
                intent.putExtra("performance", performance);
                startActivity(intent);
                break;
            case R.id.btnUpdate:
                performance.setMemo(etMemo.getText().toString());

                if (updatePerformance(performance)) {
                    Intent resultIntent = new Intent();
                    resultIntent.putExtra("performanceTitle", performance.getTitle());
                    setResult(RESULT_OK, resultIntent);
                } else {
                    setResult(RESULT_CANCELED);
                }
                finish();
                break;
            case R.id.btnUpdateCancel:
                finish();
                break;
        }
    }

    public boolean updatePerformance(Performance performance) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues value = new ContentValues();
        value.put(PerformanceDBHelper.COL_MEMO, performance.getMemo());

        String whereClause = PerformanceDBHelper.COL_ID + "=?";
        String[] whereArgs = new String[] { String.valueOf(performance.get_id()) };
        int result = db.update(PerformanceDBHelper.TABLE_NAME, value, whereClause, whereArgs);
        helper.close();
        if (result > 0) return true;
        return false;
    }
}